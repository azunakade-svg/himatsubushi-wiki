# 暇つぶしWiki（Cloudflare Pages用）

## できること
- 閲覧用パスワードでログインしてWikiを読む
- 編集用パスワードでログインすると記事の追加・編集・削除ができる
- 記事はCloudflare KVに保存される
- Wikipedia風のシンプルな画面

## 重要
このプロジェクトはCloudflare Pages Functions + KVを使います。
「静的ファイルをアップロード」だけでは動きません。GitHub連携でPagesプロジェクトを作ってください。
このZIPの中身を、既存GitHubリポジトリのルートにアップロードして既存ファイルを置き換える方法もありますが、作業前に必ず既存リポジトリをバックアップしてください。

## Cloudflare側の設定
1. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git
2. 既存のGitHubリポジトリを選択
3. Framework preset: None
4. Build command: 空欄
5. Build output directory: `public`
6. Root directory: `/`（リポジトリのルート）
7. Deployする
8. Pagesプロジェクトの Settings → Functions → KV namespace bindings で、KV namespaceを作成して binding name を `WIKI_KV` にする
9. Settings → Variables and Secrets で以下のSecretsを追加する
   - `VIEW_PASSWORD`：友達に共有する閲覧用パスワード
   - `EDIT_PASSWORD`：自分だけが使う編集用パスワード
   - `SESSION_SECRET`：十分に長いランダム文字列（32文字以上を推奨）

設定後に再デプロイしてください。

## GitHubへ反映するファイル
ZIPを解凍し、`public` と `functions` のフォルダをリポジトリのルートに置きます。
既存の `index.html` や `style.css` などは `public` に移動するのではなく、このプロジェクトの `public` が公開ファイルになります。
GitHubのルートに `functions` と `public` が並ぶ形です。

## 注意
- パスワードをHTMLやJavaScriptに書かないでください。CloudflareのSecretsにだけ保存します。
- 編集用パスワードは他の人に共有しないでください。
- 友達の本名、住所、電話番号、学校名などの個人情報は載せないでください。本人の許可を取ってから記事を公開してください。
